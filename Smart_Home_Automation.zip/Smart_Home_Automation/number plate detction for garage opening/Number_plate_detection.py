import cv2
import easyocr

# Initialize EasyOCR Reader
reader = easyocr.Reader(['en'])

# Predefined Number Plate for Matching
PREDEFINED_PLATE = "TR03MF4477"

# Open Webcam
cap = cv2.VideoCapture(0)

# Function to clean and normalize detected text
def clean_text(text):
    cleaned = text.strip().replace(" ", "").upper()
    cleaned = cleaned.replace('O', '0')  # Fix common OCR errors
    cleaned = cleaned.replace('I', '1')
    cleaned = cleaned.replace('L', '1')
    return ''.join(filter(str.isalnum, cleaned))  # Remove unwanted symbols

# Flag to Stop After Successful Detection
plate_detected = False

while not plate_detected:
    ret, frame = cap.read()
    if not ret:
        print("❌ Camera error. Exiting...")
        break

    # Resize and convert frame for OCR
    frame = cv2.resize(frame, (640, 480))
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Detect Text using EasyOCR
    results = reader.readtext(rgb_frame)

    for (bbox, text, prob) in results:
        if prob > 0.8:  # Confidence threshold
            detected_plate = clean_text(text)
            print(f"🔍 Detected: {detected_plate}")

            # Check if detected plate matches the predefined one
            if detected_plate == PREDEFINED_PLATE:
                print("✅ Number Plate Matched! Stopping detection.")
                plate_detected = True
                break  # Stop further detection

    # Display the video feed
    cv2.imshow("License Plate Detection", frame)

    # Press 'q' to exit manually
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Cleanup
cap.release()
cv2.destroyAllWindows()
