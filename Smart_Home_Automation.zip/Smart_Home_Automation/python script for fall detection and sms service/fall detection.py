import cv2
import mediapipe as mp
import serial
import time
import winsound
import requests

# Fast2SMS API Key
FAST2SMS_API_KEY = "Rd5xaidngNSNShsdG81Rbgzgi7mST3f3oK72qG0W045iKr4sgqm4EHE6gsmF"

# Recipient Numbers (Add multiple with commas)
ALERT_PHONE_1 = "9392686928"
ALERT_PHONE_2 = "recipient_number_2"

# Initialize Serial Communication with ESP32 (COM5)
esp = serial.Serial('COM5', 115200, timeout=1)
time.sleep(2)  # Allow ESP32 to initialize

# Initialize Mediapipe Pose
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(static_image_mode=False, model_complexity=1, smooth_landmarks=True)
mp_drawing = mp.solutions.drawing_utils

# Open Webcam
cap = cv2.VideoCapture(0)

# Fall Detection Parameters
FALL_THRESHOLD = 1.5  # Adjust for sensitivity
fall_detected = False  # Avoid multiple SMS alerts

def send_sms(message, phone_number):
    url = "https://www.fast2sms.com/dev/bulkV2"
    payload = {
        "message": message,
        "language": "english",
        "route": "q",
        "numbers": phone_number,
    }
    headers = {
        "authorization": FAST2SMS_API_KEY,
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    print(f"SMS Response: {response.json()}")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.resize(frame, (640, 480))
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = pose.process(rgb_frame)

    if results.pose_landmarks:
        landmarks = results.pose_landmarks.landmark

        # Get Key Points (Normalize by Frame Height)
        frame_height, frame_width, _ = frame.shape
        nose_y = landmarks[mp_pose.PoseLandmark.NOSE].y * frame_height
        left_shoulder_y = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER].y * frame_height
        right_shoulder_y = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER].y * frame_height

        # Calculate Average Shoulder Height
        avg_shoulder_y = (left_shoulder_y + right_shoulder_y) / 2

        # Detect Fall (If Nose Drops Below Shoulder by FALL_THRESHOLD)
        if nose_y > avg_shoulder_y + (FALL_THRESHOLD * 10):
            cv2.putText(frame, "⚠ FALL DETECTED!", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            winsound.Beep(1000, 500)  # Beep Alert
            esp.write(b"FALL\n")  # Send signal to ESP32 via Serial

            if not fall_detected:
                print("🚨 Sending SMS alerts...")
                send_sms("🚨 FALL DETECTED! Immediate assistance required.", ALERT_PHONE_1)
                send_sms("⚠ FALL DETECTED! Please check immediately.", ALERT_PHONE_2)
                fall_detected = True  # Prevent multiple alerts

        # Draw Landmarks
        mp_drawing.draw_landmarks(frame, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)

    # Show Output
    cv2.imshow('Fall Detection - Serial Communication', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):  # Press 'q' to exit
        break

# Cleanup
cap.release()
cv2.destroyAllWindows()
esp.close()